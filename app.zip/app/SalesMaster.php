<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class SalesMaster extends Model {

	protected $table = 'salesmaster';

}
