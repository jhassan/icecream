<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class VoucherMaster extends Model {

	protected $table = 'vouchermaster';

}
