<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchaseItems extends Model {

	protected $table = 'purchase_items';

}
