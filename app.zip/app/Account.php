<?php namespace App;

use Illuminate\Database\Eloquent\Model;
use DB,Input,Redirect,paginate;
use Session;
use App\COA;

class Account extends Model {

	protected $table = 'products';

}
