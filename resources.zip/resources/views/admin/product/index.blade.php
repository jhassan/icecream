@extends('layout.master')
@section('content')
	<input type='text' name="" class="form-control">
@stop